using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BloodDonations.Pages.Donator
{
    public class PostDataModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
