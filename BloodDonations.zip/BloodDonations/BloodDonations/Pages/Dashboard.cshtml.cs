using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BloodDonations.Pages
{
    public class DashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
